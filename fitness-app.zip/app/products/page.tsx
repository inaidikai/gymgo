import Link from "next/link"
import { ArrowRight, Bluetooth, Zap, Shield, BarChart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function ProductsPage() {
  return (
    <main className="min-h-screen">
      {/* Hero */}
      <section className="py-20 bg-gradient-to-r from-blue-50 to-indigo-100">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl font-bold tracking-tight mb-6">
                Precision Sensors for Accurate Fitness Tracking
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Our state-of-the-art pressure and force sensors track every jump, pull, and movement with incredible
                accuracy.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="gap-2">
                  Shop Now <ArrowRight className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="lg">
                  Learn More
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square bg-white rounded-xl shadow-2xl overflow-hidden">
                <img
                  src="/placeholder.svg?height=500&width=500"
                  alt="Fitness sensor product"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-lg shadow-lg">
                <div className="flex items-center gap-3">
                  <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <Bluetooth className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Wireless</p>
                    <p className="font-medium">Bluetooth 5.0</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Product Features */}
      <section className="py-20">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight mb-4">Sensor Features</h2>
            <p className="text-gray-600 md:w-3/4 mx-auto">
              Our sensors are designed to provide accurate, real-time data for all your fitness activities.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                  <Zap className="h-6 w-6 text-blue-600" />
                </div>
                <CardTitle>High Precision</CardTitle>
                <CardDescription>Accurate to within 0.1kg of force measurement for precise tracking.</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500">
                  Our sensors use advanced strain gauge technology to measure force with incredible accuracy, ensuring
                  that every jump and movement is tracked correctly.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <Bluetooth className="h-6 w-6 text-green-600" />
                </div>
                <CardTitle>Wireless Connectivity</CardTitle>
                <CardDescription>Seamless Bluetooth 5.0 connection with long battery life.</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500">
                  Connect wirelessly to your smartphone or tablet with stable, low-latency Bluetooth 5.0 technology. The
                  battery lasts up to 30 days on a single charge.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="h-12 w-12 rounded-full bg-purple-100 flex items-center justify-center mb-4">
                  <Shield className="h-6 w-6 text-purple-600" />
                </div>
                <CardTitle>Durable Design</CardTitle>
                <CardDescription>Water-resistant and shock-proof for all workout conditions.</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500">
                  Built to withstand intense workouts, our sensors are water-resistant and can handle drops and impacts,
                  making them perfect for any fitness environment.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Product Showcase */}
      <section className="py-20 bg-gray-50">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold tracking-tight mb-6">Our Sensor Technology</h2>
              <p className="text-gray-600 mb-6">
                Our sensors use advanced pressure and force detection technology to accurately track your movements.
                They can be placed on floors, walls, or equipment to monitor different types of exercises.
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-start">
                  <div className="h-6 w-6 rounded-full bg-blue-100 flex items-center justify-center mt-1 mr-3">
                    <span className="text-blue-600 text-xs">✓</span>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Jump Tracking</h3>
                    <p className="text-sm text-gray-500">Measures jump height, force, and count with precision.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="h-6 w-6 rounded-full bg-blue-100 flex items-center justify-center mt-1 mr-3">
                    <span className="text-blue-600 text-xs">✓</span>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Strength Measurement</h3>
                    <p className="text-sm text-gray-500">Tracks pulling and pushing force for strength exercises.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="h-6 w-6 rounded-full bg-blue-100 flex items-center justify-center mt-1 mr-3">
                    <span className="text-blue-600 text-xs">✓</span>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Movement Analysis</h3>
                    <p className="text-sm text-gray-500">Analyzes movement patterns to improve form and technique.</p>
                  </div>
                </div>
              </div>

              <Button>View Technical Specifications</Button>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="aspect-square bg-white rounded-lg shadow-md overflow-hidden">
                <img
                  src="/placeholder.svg?height=300&width=300"
                  alt="Jump sensor"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="aspect-square bg-white rounded-lg shadow-md overflow-hidden">
                <img
                  src="/placeholder.svg?height=300&width=300"
                  alt="Strength sensor"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="aspect-square bg-white rounded-lg shadow-md overflow-hidden">
                <img
                  src="/placeholder.svg?height=300&width=300"
                  alt="Sensor in use"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="aspect-square bg-white rounded-lg shadow-md overflow-hidden">
                <img
                  src="/placeholder.svg?height=300&width=300"
                  alt="Sensor app integration"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Product Comparison */}
      <section className="py-20">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight mb-4">Product Comparison</h2>
            <p className="text-gray-600 md:w-3/4 mx-auto">Choose the right sensor package for your fitness needs.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="border-2 border-gray-200">
              <CardHeader>
                <CardTitle>Starter Kit</CardTitle>
                <CardDescription>Perfect for beginners and casual fitness enthusiasts.</CardDescription>
                <div className="mt-4">
                  <span className="text-3xl font-bold">$99</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-center">
                    <span className="text-green-600 mr-2">✓</span>
                    <span>1 Jump Sensor</span>
                  </li>
                  <li className="flex items-center">
                    <span className="text-green-600 mr-2">✓</span>
                    <span>Basic App Features</span>
                  </li>
                  <li className="flex items-center">
                    <span className="text-green-600 mr-2">✓</span>
                    <span>7-Day Data History</span>
                  </li>
                  <li className="flex items-center text-gray-400">
                    <span className="mr-2">✗</span>
                    <span>Strength Sensor</span>
                  </li>
                  <li className="flex items-center text-gray-400">
                    <span className="mr-2">✗</span>
                    <span>Advanced Analytics</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button className="w-full">Buy Now</Button>
              </CardFooter>
            </Card>

            <Card className="border-2 border-blue-600 relative">
              <div className="absolute top-0 right-0 bg-blue-600 text-white px-3 py-1 text-xs font-medium">POPULAR</div>
              <CardHeader>
                <CardTitle>Pro Package</CardTitle>
                <CardDescription>For serious fitness enthusiasts and athletes.</CardDescription>
                <div className="mt-4">
                  <span className="text-3xl font-bold">$199</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-center">
                    <span className="text-green-600 mr-2">✓</span>
                    <span>2 Jump Sensors</span>
                  </li>
                  <li className="flex items-center">
                    <span className="text-green-600 mr-2">✓</span>
                    <span>1 Strength Sensor</span>
                  </li>
                  <li className="flex items-center">
                    <span className="text-green-600 mr-2">✓</span>
                    <span>All App Features</span>
                  </li>
                  <li className="flex items-center">
                    <span className="text-green-600 mr-2">✓</span>
                    <span>30-Day Data History</span>
                  </li>
                  <li className="flex items-center">
                    <span className="text-green-600 mr-2">✓</span>
                    <span>Basic Analytics</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button className="w-full">Buy Now</Button>
              </CardFooter>
            </Card>

            <Card className="border-2 border-gray-200">
              <CardHeader>
                <CardTitle>Elite Bundle</CardTitle>
                <CardDescription>For professional athletes and trainers.</CardDescription>
                <div className="mt-4">
                  <span className="text-3xl font-bold">$349</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-center">
                    <span className="text-green-600 mr-2">✓</span>
                    <span>4 Jump Sensors</span>
                  </li>
                  <li className="flex items-center">
                    <span className="text-green-600 mr-2">✓</span>
                    <span>2 Strength Sensors</span>
                  </li>
                  <li className="flex items-center">
                    <span className="text-green-600 mr-2">✓</span>
                    <span>All App Features</span>
                  </li>
                  <li className="flex items-center">
                    <span className="text-green-600 mr-2">✓</span>
                    <span>Unlimited Data History</span>
                  </li>
                  <li className="flex items-center">
                    <span className="text-green-600 mr-2">✓</span>
                    <span>Advanced Analytics & Reports</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button className="w-full">Buy Now</Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      {/* Data Visualization */}
      <section className="py-20 bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1">
              <div className="bg-white p-6 rounded-xl shadow-md">
                <h3 className="font-medium mb-4 flex items-center">
                  <BarChart className="h-5 w-5 text-blue-600 mr-2" /> Performance Analytics
                </h3>
                <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center mb-4">
                  <img
                    src="/placeholder.svg?height=300&width=500"
                    alt="Data visualization"
                    className="w-full h-full object-cover rounded-lg"
                  />
                </div>
                <p className="text-sm text-gray-500">
                  Sample data visualization from our app showing jump height and force over time.
                </p>
              </div>
            </div>

            <div className="order-1 md:order-2">
              <h2 className="text-3xl font-bold tracking-tight mb-6">Powerful Data Insights</h2>
              <p className="text-gray-600 mb-6">
                Our app transforms raw sensor data into meaningful insights that help you understand and improve your
                performance.
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-start">
                  <div className="h-6 w-6 rounded-full bg-blue-100 flex items-center justify-center mt-1 mr-3">
                    <span className="text-blue-600 text-xs">✓</span>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Performance Trends</h3>
                    <p className="text-sm text-gray-500">
                      Track your progress over time with detailed charts and graphs.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="h-6 w-6 rounded-full bg-blue-100 flex items-center justify-center mt-1 mr-3">
                    <span className="text-blue-600 text-xs">✓</span>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Personalized Recommendations</h3>
                    <p className="text-sm text-gray-500">
                      Get AI-powered suggestions to improve your technique and performance.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="h-6 w-6 rounded-full bg-blue-100 flex items-center justify-center mt-1 mr-3">
                    <span className="text-blue-600 text-xs">✓</span>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Exportable Reports</h3>
                    <p className="text-sm text-gray-500">
                      Share your data with coaches or trainers for professional analysis.
                    </p>
                  </div>
                </div>
              </div>

              <Button variant="outline">Learn More About Analytics</Button>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="container px-4 md:px-6 text-center">
          <h2 className="text-3xl font-bold tracking-tight mb-4">Ready to Transform Your Workouts?</h2>
          <p className="md:w-3/4 mx-auto mb-8">
            Get started with our sensors and app today and experience the future of fitness tracking.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="secondary" size="lg">
              Shop Now
            </Button>
            <Link href="/demo">
              <Button variant="outline" size="lg" className="text-white border-white hover:bg-blue-700">
                Try Demo
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </main>
  )
}

