import Link from "next/link"
import { Facebook, Twitter, Instagram, Youtube, Mail, Phone } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-white border-t border-gray-200">
      <div className="container px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="h-10 w-10 rounded-full bg-green-500 flex items-center justify-center">
                <span className="text-white font-bold text-lg">G</span>
              </div>
              <span className="font-bold text-xl text-green-500">GymGo</span>
            </div>
            <p className="text-gray-600 mb-4">
              Make fitness fun! Track workouts, earn XP, and level up your health with our gamified approach.
            </p>
            <div className="flex space-x-4">
              <Link href="#" className="text-gray-400 hover:text-green-500">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link href="#" className="text-gray-400 hover:text-green-500">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </Link>
              <Link href="#" className="text-gray-400 hover:text-green-500">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="#" className="text-gray-400 hover:text-green-500">
                <Youtube className="h-5 w-5" />
                <span className="sr-only">YouTube</span>
              </Link>
            </div>
          </div>

          <div>
            <h3 className="font-bold text-gray-800 mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-600 hover:text-green-500">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/features" className="text-gray-600 hover:text-green-500">
                  Features
                </Link>
              </li>
              <li>
                <Link href="/leaderboard" className="text-gray-600 hover:text-green-500">
                  Leaderboard
                </Link>
              </li>
              <li>
                <Link href="/products" className="text-gray-600 hover:text-green-500">
                  Shop
                </Link>
              </li>
              <li>
                <Link href="/demo" className="text-gray-600 hover:text-green-500">
                  Try It
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-gray-600 hover:text-green-500">
                  FAQ
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-gray-800 mb-4">Resources</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-gray-600 hover:text-green-500">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-600 hover:text-green-500">
                  User Guide
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-600 hover:text-green-500">
                  Support Center
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-600 hover:text-green-500">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-600 hover:text-green-500">
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-gray-800 mb-4">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <Mail className="h-5 w-5 mr-2 mt-0.5 text-green-500" />
                <span>hello@gymgo.com</span>
              </li>
              <li className="flex items-start">
                <Phone className="h-5 w-5 mr-2 mt-0.5 text-green-500" />
                <span>+1 (800) 123-4567</span>
              </li>
            </ul>
            <div className="mt-6">
              <h4 className="text-sm font-bold text-gray-800 mb-2">Join our community</h4>
              <div className="flex">
                <input
                  type="email"
                  placeholder="Your email"
                  className="px-3 py-2 bg-gray-100 text-gray-800 rounded-l-md focus:outline-none focus:ring-1 focus:ring-green-500 w-full"
                />
                <button className="bg-green-500 text-white px-4 py-2 rounded-r-md hover:bg-green-600">Join</button>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-200 mt-12 pt-8 text-center text-sm text-gray-600">
          <p>© {new Date().getFullYear()} GymGo. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

